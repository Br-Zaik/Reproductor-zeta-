package com.custom.videoplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.custom.videoplayer.databinding.ItemVideoBinding
import java.util.Locale
import java.util.concurrent.TimeUnit

class VideoAdapter(
    private var videos: List<VideoItem>,
    private val onVideoClick: (VideoItem, Int) -> Unit,
    private val onVideoMenuClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {

    inner class VideoViewHolder(val binding: ItemVideoBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val binding = ItemVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VideoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        val item = videos[position]
        holder.binding.tvVideoTitle.text = item.title
        holder.binding.tvDuration.text = formatDuration(item.duration)
        holder.binding.tvVideoSize.text = formatSize(item.size)
        holder.binding.tvVideoFolder.text = item.folderName

        val nowSeconds = System.currentTimeMillis() / 1000L
        val isRecent = (nowSeconds - item.dateAdded) < 48 * 3600
        holder.binding.tvNewBadge.visibility = if (isRecent) View.VISIBLE else View.GONE

        Glide.with(holder.itemView.context)
            .load(item.uri)
            .centerCrop()
            .into(holder.binding.ivThumbnail)

        holder.itemView.setOnClickListener { onVideoClick(item, position) }
        holder.binding.btnItemMore.setOnClickListener { onVideoMenuClick(item) }
    }

    override fun getItemCount(): Int = videos.size

    fun updateList(newList: List<VideoItem>) {
        videos = newList
        notifyDataSetChanged()
    }

    companion object {
        fun formatDuration(millis: Long): String {
            val hours = TimeUnit.MILLISECONDS.toHours(millis)
            val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
            val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
            return if (hours > 0) {
                String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
            }
        }

        fun formatSize(bytes: Long): String {
            val mb = bytes / (1024.0 * 1024.0)
            return if (mb >= 1024) {
                String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0)
            } else {
                String.format(Locale.getDefault(), "%.1f MB", mb)
            }
        }
    }
}
