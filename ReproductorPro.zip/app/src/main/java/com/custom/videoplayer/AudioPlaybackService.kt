package com.custom.videoplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class AudioPlaybackService : Service() {

    companion object {
        const val CHANNEL_ID = "reproductor_bg_audio_channel"
        const val NOTIF_ID = 1001
        const val ACTION_PLAY_PAUSE = "com.custom.videoplayer.ACTION_PLAY_PAUSE"
        const val ACTION_NEXT = "com.custom.videoplayer.ACTION_NEXT"
        const val ACTION_STOP = "com.custom.videoplayer.ACTION_STOP"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY_PAUSE -> {
                PlayerHolder.player?.let { if (it.isPlaying) it.pause() else it.play() }
                updateNotification()
            }
            ACTION_NEXT -> {
                PlayerHolder.player?.let {
                    if (it.hasNextMediaItem()) {
                        it.seekToNextMediaItem()
                        PlayerHolder.currentIndex = it.currentMediaItemIndex
                    }
                }
                updateNotification()
            }
            ACTION_STOP -> {
                PlayerHolder.isAudioBackgroundMode = false
                PlayerHolder.player?.pause()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(NOTIF_ID, buildNotification())
            }
        }
        return START_STICKY
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val title = PlayerHolder.videoTitles.getOrNull(PlayerHolder.currentIndex) ?: "Reproduciendo audio"
        val isPlaying = PlayerHolder.player?.isPlaying == true

        val openAppIntent = Intent(this, PlayerActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentPending = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIntent = PendingIntent.getService(
            this, 1, Intent(this, AudioPlaybackService::class.java).setAction(ACTION_PLAY_PAUSE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val nextIntent = PendingIntent.getService(
            this, 2, Intent(this, AudioPlaybackService::class.java).setAction(ACTION_NEXT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 3, Intent(this, AudioPlaybackService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_headphones)
            .setContentTitle(title)
            .setContentText("Modo Audio en segundo plano")
            .setContentIntent(contentPending)
            .setOngoing(isPlaying)
            .addAction(
                if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                if (isPlaying) "Pausar" else "Reproducir",
                playPauseIntent
            )
            .addAction(R.drawable.ic_next, "Siguiente", nextIntent)
            .addAction(R.drawable.ic_close, "Cerrar", stopIntent)
            .setStyle(
                androidx.media.app.NotificationCompat.MediaStyle()
                    .setShowActionsInCompactView(0, 1, 2)
            )
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Reproducción de Audio en Segundo Plano",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
