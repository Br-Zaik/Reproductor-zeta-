package com.custom.videoplayer

import android.net.Uri

data class VideoItem(
    val id: Long,
    val title: String,
    val duration: Long,
    val size: Long,
    val folderName: String,
    val folderPath: String,
    val path: String,
    val uri: Uri,
    val dateAdded: Long
)

data class FolderItem(
    val name: String,
    val path: String,
    val videoCount: Int
)
