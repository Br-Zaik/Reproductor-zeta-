package com.custom.videoplayer

import androidx.media3.exoplayer.ExoPlayer

object PlayerHolder {
    var player: ExoPlayer? = null
    var videoUris: ArrayList<String> = arrayListOf()
    var videoTitles: ArrayList<String> = arrayListOf()
    var currentIndex: Int = 0
    var isAudioBackgroundMode: Boolean = false
}
