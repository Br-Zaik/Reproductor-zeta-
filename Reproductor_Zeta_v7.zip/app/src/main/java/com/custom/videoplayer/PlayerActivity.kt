package com.custom.videoplayer

import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import com.custom.videoplayer.databinding.ActivityPlayerBinding
import com.custom.videoplayer.databinding.DialogEqualizerBinding
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.abs

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private var player: ExoPlayer? = null
    private lateinit var audioManager: AudioManager

    private var videoUris = ArrayList<String>()
    private var videoTitles = ArrayList<String>()
    private var currentIndex = 0
    private var explicitResumePosition = -1L

    private var isLocked = false
    private var isMuted = false
    private var isMirrored = false
    private var isNightMode = false
    private var controlsVisible = true

    // Zoom & Long-Press Speed
    private var currentZoom = 1.0f
    private var isScaling = false
    private var isLongPressFast = false

    private var currentSpeedIndex = 2
    private val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

    private var currentAspectIndex = 0
    private val aspectNames = arrayOf("Fit", "Rellenar", "Match", "Original", "16:9", "4:3")

    private var currentPlayModeIndex = 1
    private val playModeNames = arrayOf("Sequential play", "List loop", "Single cycle", "Shuffle playback")

    private var abPointA: Long? = null
    private var abPointB: Long? = null
    private var sleepRunnable: Runnable? = null

    // Audio FX + Volume Boost (up to 200%)
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var presetReverb: PresetReverb? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var currentBoostPercent = 0 // 0..100 extra (100%..200%)

    private val handler = Handler(Looper.getMainLooper())
    private val hideControlsRunnable = Runnable { setControlsVisibility(false) }
    private val hideHudRunnable = Runnable { binding.gestureFeedbackContainer.visibility = View.GONE }
    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            updateSeekBarAndAbLoop()
            handler.postDelayed(this, 300)
        }
    }

    private val subtitlePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { subUri ->
            val exo = player ?: return@let
            val currentUriStr = videoUris.getOrNull(currentIndex) ?: return@let
            val currentTitle = videoTitles.getOrNull(currentIndex) ?: "Video"
            val currentPos = exo.currentPosition
            val mimeType = when {
                subUri.toString().endsWith(".vtt", true) -> MimeTypes.TEXT_VTT
                subUri.toString().endsWith(".ass", true) -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            val subConfig = MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType(mimeType)
                .setLanguage("es")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            val newItem = MediaItem.Builder()
                .setUri(Uri.parse(currentUriStr))
                .setMediaMetadata(MediaMetadata.Builder().setTitle(currentTitle).build())
                .setSubtitleConfigurations(listOf(subConfig))
                .build()
            exo.setMediaItem(newItem, currentPos)
            exo.prepare()
            exo.playWhenReady = true
            Toast.makeText(this, "Subtítulo externo cargado", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        handleIntent(intent)
        setupControls()
        setupGestures()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent) {
        val resumeFromAudio = intent.getBooleanExtra("RESUME_FROM_AUDIO", false)
        if (resumeFromAudio && PlayerHolder.player != null) {
            PlayerHolder.isAudioBackgroundMode = false
            stopService(Intent(this, AudioPlaybackService::class.java))
            player = PlayerHolder.player
            videoUris = PlayerHolder.videoUris
            videoTitles = PlayerHolder.videoTitles
            currentIndex = PlayerHolder.currentIndex
            binding.playerView.player = player
            updateTitle()
            handler.post(updateProgressRunnable)
            scheduleHideControls()
            return
        }

        if (PlayerHolder.isAudioBackgroundMode) {
            PlayerHolder.isAudioBackgroundMode = false
            stopService(Intent(this, AudioPlaybackService::class.java))
        }

        val intentData = intent.data
        if (intentData != null) {
            videoUris = arrayListOf(intentData.toString())
            videoTitles = arrayListOf(intentData.lastPathSegment ?: "Video externo")
            currentIndex = 0
            explicitResumePosition = -1L
        } else {
            videoUris = intent.getStringArrayListExtra("VIDEO_URIS") ?: arrayListOf()
            videoTitles = intent.getStringArrayListExtra("VIDEO_TITLES") ?: arrayListOf()
            currentIndex = intent.getIntExtra("START_INDEX", 0)
            explicitResumePosition = intent.getLongExtra("RESUME_POSITION", -1L)
        }

        PlayerHolder.videoUris = videoUris
        PlayerHolder.videoTitles = videoTitles
        PlayerHolder.currentIndex = currentIndex

        setupPlayer()
    }

    private fun setupPlayer() {
        releaseAudioEffects()
        player?.release()

        // Optimized fast-start buffers & audio focus management
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 35_000, 1_000, 2_000)
            .build()

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val startUri = videoUris.getOrNull(currentIndex)
        val savedPos = if (explicitResumePosition >= 0L) {
            explicitResumePosition
        } else if (startUri != null) {
            getSharedPreferences("video_progress_prefs", Context.MODE_PRIVATE).getLong(startUri, 0L)
        } else {
            0L
        }

        player = ExoPlayer.Builder(this)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .also { exo ->
                PlayerHolder.player = exo
                binding.playerView.player = exo

                val mediaItems = videoUris.map { MediaItem.fromUri(Uri.parse(it)) }
                exo.setMediaItems(mediaItems, currentIndex, savedPos.coerceAtLeast(0L))
                exo.repeatMode = Player.REPEAT_MODE_ALL
                exo.prepare()
                exo.playWhenReady = true

                updateTitle()
                if (savedPos > 5000L) {
                    showGestureFeedback("Reanudado en ${VideoAdapter.formatDuration(savedPos)}", null, null)
                }

                exo.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        binding.btnPlayPause.setImageResource(
                            if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                        )
                    }

                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        saveCurrentVideoProgress()
                        currentIndex = exo.currentMediaItemIndex
                        PlayerHolder.currentIndex = currentIndex
                        clearAbCycle()
                        resetZoom()
                        updateTitle()
                    }

                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            initAudioEffects(exo.audioSessionId)
                            binding.tvTotalTime.text = VideoAdapter.formatDuration(exo.duration.coerceAtLeast(0L))
                            binding.seekBar.max = exo.duration.toInt().coerceAtLeast(0)
                        }
                    }
                })
            }

        handler.post(updateProgressRunnable)
        scheduleHideControls()
    }

    private fun initAudioEffects(audioSessionId: Int) {
        if (audioSessionId == 0 || equalizer != null) return
        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
            virtualizer = Virtualizer(0, audioSessionId).apply { enabled = true }
            presetReverb = PresetReverb(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                enabled = currentBoostPercent > 0
                if (currentBoostPercent > 0) setTargetGain(currentBoostPercent * 18)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseAudioEffects() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { presetReverb?.release() } catch (_: Exception) {}
        try { loudnessEnhancer?.release() } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
        virtualizer = null
        presetReverb = null
        loudnessEnhancer = null
    }

    private fun updateTitle() {
        val title = videoTitles.getOrNull(currentIndex) ?: "Video"
        binding.tvPlayerTitle.text = title
    }

    private fun applyTransform() {
        val sign = if (isMirrored) -1f else 1f
        binding.playerView.scaleX = sign * currentZoom
        binding.playerView.scaleY = currentZoom
    }

    private fun resetZoom() {
        currentZoom = 1.0f
        applyTransform()
    }

    private fun setupControls() {
        binding.btnBack.setOnClickListener { finish() }

        binding.btnPlayPause.setOnClickListener {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
            scheduleHideControls()
        }

        binding.btnPrev.setOnClickListener {
            saveCurrentVideoProgress()
            player?.let {
                if (it.hasPreviousMediaItem()) it.seekToPreviousMediaItem() else it.seekTo(0)
            }
            scheduleHideControls()
        }

        binding.btnNext.setOnClickListener {
            saveCurrentVideoProgress()
            player?.let {
                if (it.hasNextMediaItem()) it.seekToNextMediaItem()
            }
            scheduleHideControls()
        }

        binding.btnLock.setOnClickListener {
            isLocked = true
            setControlsVisibility(false)
            binding.btnUnlock.visibility = View.VISIBLE
            Toast.makeText(this, "Pantalla bloqueada", Toast.LENGTH_SHORT).show()
        }

        binding.btnUnlock.setOnClickListener {
            isLocked = false
            binding.btnUnlock.visibility = View.GONE
            setControlsVisibility(true)
            scheduleHideControls()
        }

        binding.btnRotate.setOnClickListener {
            requestedOrientation = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            } else {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
            scheduleHideControls()
        }

        binding.btnMute.setOnClickListener {
            isMuted = !isMuted
            player?.volume = if (isMuted) 0f else 1f
            binding.btnMute.alpha = if (isMuted) 0.45f else 1.0f
            scheduleHideControls()
        }

        binding.btnSpeed.setOnClickListener {
            currentSpeedIndex = (currentSpeedIndex + 1) % speeds.size
            val newSpeed = speeds[currentSpeedIndex]
            player?.playbackParameters = PlaybackParameters(newSpeed)
            binding.btnSpeed.text = "${newSpeed}x"
            scheduleHideControls()
        }

        binding.btnAspect.setOnClickListener {
            resetZoom()
            currentAspectIndex = (currentAspectIndex + 1) % aspectNames.size
            applyAspectMode(currentAspectIndex)
            scheduleHideControls()
        }

        binding.btnCutSegment.setOnClickListener {
            toggleAbCycle()
            scheduleHideControls()
        }

        binding.btnScreenshot.setOnClickListener {
            captureVideoScreenshot()
            scheduleHideControls()
        }

        binding.btnSubtitles.setOnClickListener {
            showTracksMenuDialog()
            scheduleHideControls()
        }

        binding.tvAbBadge.setOnClickListener {
            clearAbCycle()
            Toast.makeText(this, "Bucle A-B desactivado", Toast.LENGTH_SHORT).show()
        }

        binding.btnPlaylist.setOnClickListener {
            showPlaylistDialog()
            scheduleHideControls()
        }

        binding.btnPlayerMore.setOnClickListener { view ->
            showMoreOptionsMenu(view)
            scheduleHideControls()
        }

        binding.btnPip.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } else {
                Toast.makeText(this, "PiP no soportado en esta versión", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnEqualizer.setOnClickListener {
            showEqualizerDialog()
            scheduleHideControls()
        }

        binding.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    player?.seekTo(progress.toLong())
                    binding.tvCurrentTime.text = VideoAdapter.formatDuration(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                handler.removeCallbacks(hideControlsRunnable)
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                scheduleHideControls()
            }
        })
    }

    private fun captureVideoScreenshot() {
        val textureView = binding.playerView.videoSurfaceView as? TextureView
        val bitmap = textureView?.bitmap
        if (bitmap == null) {
            Toast.makeText(this, "No se pudo capturar el fotograma", Toast.LENGTH_SHORT).show()
            return
        }

        val filename = "Zeta_${System.currentTimeMillis()}.jpg"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/ReproductorZeta")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                uri?.let {
                    contentResolver.openOutputStream(it)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                    }
                }
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                if (dir != null && !dir.exists()) dir.mkdirs()
                val file = File(dir, filename)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                }
            }
            Toast.makeText(this, "Captura guardada en Galería", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Error al guardar la captura", Toast.LENGTH_SHORT).show()
        } finally {
            bitmap.recycle()
        }
    }

    private fun showTracksMenuDialog() {
        val options = arrayOf(
            "Pistas de Audio integradas",
            "Subtítulos integrados",
            "Cargar subtítulo externo (.srt / .vtt / .ass)"
        )
        AlertDialog.Builder(this)
            .setTitle("Audio y Subtítulos")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showTrackSelectorDialog(C.TRACK_TYPE_AUDIO, "Pistas de Audio")
                    1 -> showTrackSelectorDialog(C.TRACK_TYPE_TEXT, "Subtítulos integrados")
                    2 -> subtitlePicker.launch("*/*")
                }
            }
            .show()
    }

    private fun showTrackSelectorDialog(trackType: Int, title: String) {
        val exo = player ?: return
        val tracks = exo.currentTracks
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        var checkedIndex = -1

        if (trackType == C.TRACK_TYPE_TEXT) {
            labels.add("Desactivar subtítulos")
            actions.add {
                exo.trackSelectionParameters = exo.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                Toast.makeText(this, "Subtítulos desactivados", Toast.LENGTH_SHORT).show()
            }
            if (exo.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)) {
                checkedIndex = 0
            }
        }

        for (group in tracks.groups) {
            if (group.type == trackType) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val lang = format.language?.uppercase(Locale.getDefault()) ?: "Pista ${labels.size + 1}"
                    val name = if (!format.label.isNullOrBlank()) "${format.label} ($lang)" else lang
                    if (group.isTrackSelected(i)) {
                        checkedIndex = labels.size
                    }
                    labels.add(name)
                    val targetGroup = group.mediaTrackGroup
                    val targetIdx = i
                    actions.add {
                        exo.trackSelectionParameters = exo.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(trackType, false)
                            .setOverrideForType(TrackSelectionOverride(targetGroup, targetIdx))
                            .build()
                        Toast.makeText(this, "Seleccionado: $name", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        if (labels.isEmpty() || (trackType == C.TRACK_TYPE_TEXT && labels.size == 1)) {
            Toast.makeText(this, "Este video no tiene pistas adicionales", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), checkedIndex) { dialog, which ->
                actions[which].invoke()
                dialog.dismiss()
            }
            .show()
    }

    private fun showMoreOptionsMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, "Audio (Segundo plano)")
        popup.menu.add(0, 2, 1, "AB cycle (Bucle A-B)")
        popup.menu.add(0, 3, 2, if (isMirrored) "Mirror flip (Desactivar)" else "Mirror flip (Espejo)")
        popup.menu.add(0, 4, 3, "Proporción (${aspectNames[currentAspectIndex]})")
        popup.menu.add(0, 5, 4, "Sleep (Temporizador)")
        popup.menu.add(0, 6, 5, "Play Mode (${playModeNames[currentPlayModeIndex]})")
        popup.menu.add(0, 7, 6, if (isNightMode) "Modo Nocturno (Desactivar)" else "Modo Nocturno (Luz cálida)")
        popup.menu.add(0, 8, 7, "Restablecer Zoom (1.0x)")

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> { switchToBackgroundAudioMode(); true }
                2 -> { toggleAbCycle(); true }
                3 -> {
                    isMirrored = !isMirrored
                    applyTransform()
                    Toast.makeText(this, if (isMirrored) "Modo espejo activado" else "Modo espejo desactivado", Toast.LENGTH_SHORT).show()
                    true
                }
                4 -> { showAspectRatioDialog(); true }
                5 -> { showSleepTimerDialog(); true }
                6 -> { showPlayModeDialog(); true }
                7 -> {
                    isNightMode = !isNightMode
                    binding.nightModeOverlay.visibility = if (isNightMode) View.VISIBLE else View.GONE
                    Toast.makeText(this, if (isNightMode) "Modo Nocturno activado" else "Modo Nocturno desactivado", Toast.LENGTH_SHORT).show()
                    true
                }
                8 -> {
                    resetZoom()
                    showGestureFeedback("Zoom: 100%", null, null)
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun switchToBackgroundAudioMode() {
        PlayerHolder.isAudioBackgroundMode = true
        val serviceIntent = Intent(this, AudioPlaybackService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "Reproduciendo audio en segundo plano", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun toggleAbCycle() {
        val exo = player ?: return
        val pos = exo.currentPosition
        when {
            abPointA == null -> {
                abPointA = pos
                binding.tvAbBadge.visibility = View.VISIBLE
                binding.tvAbBadge.text = "A: ${VideoAdapter.formatDuration(pos)}"
                Toast.makeText(this, "Punto A fijado. Pulsa de nuevo para fijar B", Toast.LENGTH_SHORT).show()
            }
            abPointB == null -> {
                if (pos > (abPointA ?: 0L) + 1000L) {
                    abPointB = pos
                    binding.tvAbBadge.text = "A-B Activo"
                    Toast.makeText(this, "Bucle A-B activado", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "El punto B debe ser posterior al punto A", Toast.LENGTH_SHORT).show()
                }
            }
            else -> {
                clearAbCycle()
                Toast.makeText(this, "Bucle A-B desactivado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun clearAbCycle() {
        abPointA = null
        abPointB = null
        binding.tvAbBadge.visibility = View.GONE
    }

    private fun applyAspectMode(index: Int) {
        currentAspectIndex = index
        when (index) {
            0 -> binding.playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            1 -> binding.playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
            2 -> binding.playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            3 -> binding.playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            4 -> binding.playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
            5 -> binding.playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
        }
        showGestureFeedback("Proporción: ${aspectNames[index]}", null, null)
    }

    private fun showAspectRatioDialog() {
        AlertDialog.Builder(this)
            .setTitle("Proporción de pantalla")
            .setSingleChoiceItems(aspectNames, currentAspectIndex) { dialog, which ->
                resetZoom()
                applyAspectMode(which)
                dialog.dismiss()
            }
            .show()
    }

    private fun showSleepTimerDialog() {
        val options = arrayOf("No", "10 min", "30 min", "60 min", "90 min", "Personalizado")
        AlertDialog.Builder(this)
            .setTitle("Sleep (Temporizador)")
            .setItems(options) { _, which ->
                sleepRunnable?.let { handler.removeCallbacks(it) }
                when (which) {
                    0 -> Toast.makeText(this, "Temporizador desactivado", Toast.LENGTH_SHORT).show()
                    1 -> setSleepMinutes(10)
                    2 -> setSleepMinutes(30)
                    3 -> setSleepMinutes(60)
                    4 -> setSleepMinutes(90)
                    5 -> showCustomSleepDialog()
                }
            }
            .show()
    }

    private fun showCustomSleepDialog() {
        val input = EditText(this).apply {
            hint = "Minutos (ej. 45)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Minutos personalizados")
            .setView(input)
            .setPositiveButton("Aceptar") { _, _ ->
                val mins = input.text.toString().toIntOrNull()
                if (mins != null && mins > 0) setSleepMinutes(mins)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun setSleepMinutes(minutes: Int) {
        sleepRunnable?.let { handler.removeCallbacks(it) }
        sleepRunnable = Runnable {
            player?.pause()
            Toast.makeText(this, "Temporizador cumplido: reproducción pausada", Toast.LENGTH_LONG).show()
        }
        handler.postDelayed(sleepRunnable!!, minutes * 60_000L)
        Toast.makeText(this, "Se pausará en $minutes min", Toast.LENGTH_SHORT).show()
    }

    private fun showPlayModeDialog() {
        AlertDialog.Builder(this)
            .setTitle("Play Mode")
            .setSingleChoiceItems(playModeNames, currentPlayModeIndex) { dialog, which ->
                currentPlayModeIndex = which
                player?.let { exo ->
                    when (which) {
                        0 -> { exo.shuffleModeEnabled = false; exo.repeatMode = Player.REPEAT_MODE_OFF }
                        1 -> { exo.shuffleModeEnabled = false; exo.repeatMode = Player.REPEAT_MODE_ALL }
                        2 -> { exo.shuffleModeEnabled = false; exo.repeatMode = Player.REPEAT_MODE_ONE }
                        3 -> { exo.shuffleModeEnabled = true; exo.repeatMode = Player.REPEAT_MODE_ALL }
                    }
                }
                Toast.makeText(this, "Modo: ${playModeNames[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .show()
    }

    private fun showPlaylistDialog() {
        val items = videoTitles.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Lista de reproducción (${items.size})")
            .setSingleChoiceItems(items, currentIndex) { dialog, which ->
                saveCurrentVideoProgress()
                currentIndex = which
                PlayerHolder.currentIndex = which
                player?.seekTo(which, 0L)
                updateTitle()
                dialog.dismiss()
            }
            .show()
    }

    private fun setupGestures() {
        var initialVolume = 0
        var initialBrightness = 0.5f
        var initialSeekPos = 0L
        var gestureMode = 0

        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                if (isLocked) return false
                isScaling = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (isLocked) return false
                currentZoom = (currentZoom * detector.scaleFactor).coerceIn(1.0f, 3.0f)
                applyTransform()
                val pct = (currentZoom * 100).toInt()
                showGestureFeedback("Zoom: $pct%", null, null)
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                isScaling = false
            }
        })

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (isLocked) {
                    binding.btnUnlock.visibility =
                        if (binding.btnUnlock.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                } else {
                    setControlsVisibility(!controlsVisible)
                    if (controlsVisible) scheduleHideControls()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isLocked) return true
                val screenWidth = binding.playerRoot.width
                player?.let { exo ->
                    if (e.x < screenWidth / 2f) {
                        val target = (exo.currentPosition - 10_000L).coerceAtLeast(0L)
                        exo.seekTo(target)
                        showGestureFeedback("-10s", VideoAdapter.formatDuration(target), null)
                    } else {
                        val target = (exo.currentPosition + 10_000L).coerceAtMost(exo.duration.coerceAtLeast(0L))
                        exo.seekTo(target)
                        showGestureFeedback("+10s", VideoAdapter.formatDuration(target), null)
                    }
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (isLocked || isScaling) return
                player?.let { exo ->
                    if (exo.isPlaying) {
                        isLongPressFast = true
                        exo.playbackParameters = PlaybackParameters(2.0f)
                        binding.tvFastForwardBadge.visibility = View.VISIBLE
                    }
                }
            }

            override fun onDown(e: MotionEvent): Boolean {
                gestureMode = 0
                initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val lp = window.attributes
                initialBrightness = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                initialSeekPos = player?.currentPosition ?: 0L
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (isLocked || isScaling || isLongPressFast || e1 == null) return true
                val deltaX = e2.x - e1.x
                val deltaY = e1.y - e2.y
                val width = binding.playerRoot.width.toFloat()
                val height = binding.playerRoot.height.toFloat()

                if (gestureMode == 0) {
                    gestureMode = if (abs(deltaX) > abs(deltaY)) 3 else if (e1.x < width / 2f) 1 else 2
                }

                when (gestureMode) {
                    1 -> {
                        val change = deltaY / height
                        val newBrightness = (initialBrightness + change).coerceIn(0.05f, 1.0f)
                        val lp = window.attributes
                        lp.screenBrightness = newBrightness
                        window.attributes = lp
                        val pct = (newBrightness * 100).toInt()
                        showGestureFeedback("Brillo: $pct%", null, pct)
                    }
                    2 -> {
                        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val change = ((deltaY / height) * maxVol).toInt()
                        val newVol = (initialVolume + change).coerceIn(0, maxVol)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                        val pct = ((newVol.toFloat() / maxVol) * 100).toInt()
                        showGestureFeedback("Volumen: $pct%", null, pct)
                    }
                    3 -> {
                        val exo = player ?: return true
                        val duration = exo.duration.coerceAtLeast(1L)
                        val offsetMillis = ((deltaX / width) * 60_000L).toLong()
                        val targetPos = (initialSeekPos + offsetMillis).coerceIn(0L, duration)
                        exo.seekTo(targetPos)
                        val diffSec = (targetPos - initialSeekPos) / 1000L
                        val sign = if (diffSec >= 0) "+" else ""
                        showGestureFeedback(
                            "$sign${diffSec}s",
                            "${VideoAdapter.formatDuration(targetPos)} / ${VideoAdapter.formatDuration(duration)}",
                            null
                        )
                    }
                }
                return true
            }
        })

        binding.playerRoot.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            if (!scaleDetector.isInProgress) {
                detector.onTouchEvent(event)
            }
            if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                if (isLongPressFast) {
                    isLongPressFast = false
                    player?.playbackParameters = PlaybackParameters(speeds[currentSpeedIndex])
                    binding.tvFastForwardBadge.visibility = View.GONE
                }
                handler.removeCallbacks(hideHudRunnable)
                handler.postDelayed(hideHudRunnable, 650)
            }
            true
        }
    }

    private fun showGestureFeedback(title: String, subtitle: String?, progressPercent: Int?) {
        handler.removeCallbacks(hideHudRunnable)
        binding.gestureFeedbackContainer.visibility = View.VISIBLE
        binding.tvGestureTitle.text = title
        if (subtitle != null) {
            binding.tvGestureSubtitle.visibility = View.VISIBLE
            binding.tvGestureSubtitle.text = subtitle
        } else {
            binding.tvGestureSubtitle.visibility = View.GONE
        }
        if (progressPercent != null) {
            binding.pbGestureBar.visibility = View.VISIBLE
            binding.pbGestureBar.progress = progressPercent.coerceIn(0, 100)
        } else {
            binding.pbGestureBar.visibility = View.GONE
        }
        handler.postDelayed(hideHudRunnable, 1200)
    }

    private fun setControlsVisibility(visible: Boolean) {
        controlsVisible = visible
        binding.controlsOverlay.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun scheduleHideControls() {
        handler.removeCallbacks(hideControlsRunnable)
        handler.postDelayed(hideControlsRunnable, 4000)
    }

    private fun updateSeekBarAndAbLoop() {
        player?.let { exo ->
            val pos = exo.currentPosition.coerceAtLeast(0L)
            val dur = exo.duration.coerceAtLeast(0L)
            binding.seekBar.max = dur.toInt()
            binding.seekBar.progress = pos.toInt()
            binding.tvCurrentTime.text = VideoAdapter.formatDuration(pos)
            binding.tvTotalTime.text = VideoAdapter.formatDuration(dur)

            val pointA = abPointA
            val pointB = abPointB
            if (pointA != null && pointB != null && pos >= pointB) {
                exo.seekTo(pointA)
            }
        }
    }

    private fun showEqualizerDialog() {
        val eq = equalizer
        if (eq == null) {
            Toast.makeText(this, "Ecualizador no disponible para este audio", Toast.LENGTH_SHORT).show()
            return
        }

        val dialogBinding = DialogEqualizerBinding.inflate(layoutInflater)
        dialogBinding.switchEq.isChecked = eq.enabled
        dialogBinding.switchEq.setOnCheckedChangeListener { _, isChecked -> eq.enabled = isChecked }

        // Volume Boost (100% to 200%)
        dialogBinding.seekVolumeBoost.progress = currentBoostPercent
        dialogBinding.tvBoostLabel.text = "Amplificador de Volumen: ${100 + currentBoostPercent}%"
        dialogBinding.seekVolumeBoost.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    currentBoostPercent = progress
                    dialogBinding.tvBoostLabel.text = "Amplificador de Volumen: ${100 + progress}%"
                    try {
                        loudnessEnhancer?.enabled = progress > 0
                        loudnessEnhancer?.setTargetGain(progress * 18)
                    } catch (_: Exception) {
                    }
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val bands = eq.numberOfBands
        val minLevel = eq.bandLevelRange[0]
        val maxLevel = eq.bandLevelRange[1]
        val bandSeekBars = mutableListOf<SeekBar>()

        for (i in 0 until bands) {
            val bandIndex = i.toShort()
            val freqHz = eq.getCenterFreq(bandIndex) / 1000

            val label = TextView(this).apply {
                text = "${freqHz} Hz"
                setTextColor(ContextCompat.getColor(this@PlayerActivity, R.color.text_secondary))
                textSize = 12f
                setPadding(0, 10, 0, 2)
            }

            val seek = SeekBar(this).apply {
                max = maxLevel - minLevel
                progress = eq.getBandLevel(bandIndex) - minLevel
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, prog: Int, fromUser: Boolean) {
                        if (fromUser) eq.setBandLevel(bandIndex, (prog + minLevel).toShort())
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            }

            bandSeekBars.add(seek)
            dialogBinding.eqBandsContainer.addView(label)
            dialogBinding.eqBandsContainer.addView(seek)
        }

        val presetCount = eq.numberOfPresets.toInt()
        for (p in 0 until presetCount) {
            val presetIdx = p.toShort()
            val presetName = eq.getPresetName(presetIdx)
            val btn = Button(this).apply {
                text = presetName
                textSize = 11f
                setOnClickListener {
                    eq.usePreset(presetIdx)
                    for (b in 0 until bands) {
                        bandSeekBars[b].progress = eq.getBandLevel(b.toShort()) - minLevel
                    }
                }
            }
            dialogBinding.presetsContainer.addView(btn)
        }

        dialogBinding.seekBassBoost.progress = bassBoost?.roundedStrength?.toInt() ?: 0
        dialogBinding.seekBassBoost.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { try { bassBoost?.setStrength(progress.toShort()) } catch (_: Exception) {} }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        dialogBinding.seekVirtualizer.progress = virtualizer?.roundedStrength?.toInt() ?: 0
        dialogBinding.seekVirtualizer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { try { virtualizer?.setStrength(progress.toShort()) } catch (_: Exception) {} }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        val reverbOptions = arrayOf("None", "Small Room", "Medium Room", "Large Room", "Medium Hall", "Large Hall", "Plate")
        val reverbValues = shortArrayOf(
            PresetReverb.PRESET_NONE,
            PresetReverb.PRESET_SMALLROOM,
            PresetReverb.PRESET_MEDIUMROOM,
            PresetReverb.PRESET_LARGEROOM,
            PresetReverb.PRESET_MEDIUMHALL,
            PresetReverb.PRESET_LARGEHALL,
            PresetReverb.PRESET_PLATE
        )
        dialogBinding.spinnerReverb.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, reverbOptions)
        dialogBinding.spinnerReverb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                try { presetReverb?.preset = reverbValues[position] } catch (_: Exception) {}
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setPositiveButton("Listo", null)
            .show()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!PlayerHolder.isAudioBackgroundMode && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && player?.isPlaying == true) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            setControlsVisibility(false)
            binding.btnUnlock.visibility = View.GONE
        } else if (!isLocked) {
            setControlsVisibility(true)
        }
    }

    override fun onPause() {
        super.onPause()
        saveCurrentVideoProgress()
        if (PlayerHolder.isAudioBackgroundMode) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode) return
        player?.pause()
    }

    private fun saveCurrentVideoProgress() {
        val exo = player ?: return
        val uri = videoUris.getOrNull(currentIndex) ?: return
        val title = videoTitles.getOrNull(currentIndex) ?: "Video"
        val pos = exo.currentPosition.coerceAtLeast(0L)
        val dur = exo.duration.coerceAtLeast(0L)

        // Reset saved progress if user reached >96% of the video
        val storedPos = if (dur > 0L && pos > (dur * 96L) / 100L) 0L else pos

        getSharedPreferences("video_progress_prefs", Context.MODE_PRIVATE).edit()
            .putLong(uri, storedPos)
            .apply()

        getSharedPreferences("player_prefs", Context.MODE_PRIVATE).edit()
            .putString("last_uri", uri)
            .putString("last_title", title)
            .putLong("last_pos", storedPos)
            .apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        if (!PlayerHolder.isAudioBackgroundMode) {
            releaseAudioEffects()
            player?.release()
            player = null
            PlayerHolder.player = null
        }
    }
}
