package com.custom.videoplayer

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.custom.videoplayer.databinding.ItemVideoBinding
import com.custom.videoplayer.databinding.ItemVideoGridBinding
import java.util.Locale
import java.util.concurrent.TimeUnit

class VideoAdapter(
    private var videos: List<VideoItem>,
    private val onVideoClick: (VideoItem, Int) -> Unit,
    private val onVideoMenuClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var isGridMode: Boolean = false

    inner class ListViewHolder(val binding: ItemVideoBinding) : RecyclerView.ViewHolder(binding.root)
    inner class GridViewHolder(val binding: ItemVideoGridBinding) : RecyclerView.ViewHolder(binding.root)

    override fun getItemViewType(position: Int): Int = if (isGridMode) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == 1) {
            GridViewHolder(ItemVideoGridBinding.inflate(inflater, parent, false))
        } else {
            ListViewHolder(ItemVideoBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = videos[position]
        val context = holder.itemView.context
        val nowSeconds = System.currentTimeMillis() / 1000L
        val isRecent = (nowSeconds - item.dateAdded) < 48 * 3600

        val progressPrefs = context.getSharedPreferences("video_progress_prefs", Context.MODE_PRIVATE)
        val savedPos = progressPrefs.getLong(item.uri.toString(), 0L)
        val progressPct = if (item.duration > 0L && savedPos > 2000L) {
            ((savedPos * 100L) / item.duration).toInt().coerceIn(0, 100)
        } else {
            0
        }

        if (holder is ListViewHolder) {
            holder.binding.tvVideoTitle.text = item.title
            holder.binding.tvDuration.text = formatDuration(item.duration)
            holder.binding.tvVideoSize.text = formatSize(item.size)
            holder.binding.tvVideoFolder.text = item.folderName
            holder.binding.tvNewBadge.visibility = if (isRecent) View.VISIBLE else View.GONE

            if (progressPct in 1..98) {
                holder.binding.pbWatchProgress.visibility = View.VISIBLE
                holder.binding.pbWatchProgress.progress = progressPct
            } else {
                holder.binding.pbWatchProgress.visibility = View.GONE
            }

            Glide.with(context)
                .load(item.uri)
                .override(320, 180)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .dontAnimate()
                .centerCrop()
                .into(holder.binding.ivThumbnail)

            holder.itemView.setOnClickListener { onVideoClick(item, position) }
            holder.binding.btnItemMore.setOnClickListener { onVideoMenuClick(item) }
        } else if (holder is GridViewHolder) {
            holder.binding.tvVideoTitle.text = item.title
            holder.binding.tvDuration.text = formatDuration(item.duration)
            holder.binding.tvVideoSize.text = formatSize(item.size)
            holder.binding.tvNewBadge.visibility = if (isRecent) View.VISIBLE else View.GONE

            if (progressPct in 1..98) {
                holder.binding.pbWatchProgress.visibility = View.VISIBLE
                holder.binding.pbWatchProgress.progress = progressPct
            } else {
                holder.binding.pbWatchProgress.visibility = View.GONE
            }

            Glide.with(context)
                .load(item.uri)
                .override(380, 220)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .dontAnimate()
                .centerCrop()
                .into(holder.binding.ivThumbnail)

            holder.itemView.setOnClickListener { onVideoClick(item, position) }
            holder.binding.btnItemMore.setOnClickListener { onVideoMenuClick(item) }
        }
    }

    override fun getItemCount(): Int = videos.size

    fun setGridMode(grid: Boolean) {
        if (isGridMode != grid) {
            isGridMode = grid
            notifyDataSetChanged()
        }
    }

    fun updateList(newList: List<VideoItem>) {
        videos = newList
        notifyDataSetChanged()
    }

    companion object {
        fun formatDuration(millis: Long): String {
            val hours = TimeUnit.MILLISECONDS.toHours(millis)
            val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60
            val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60
            return if (hours > 0) {
                String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
            }
        }

        fun formatSize(bytes: Long): String {
            val mb = bytes / (1024.0 * 1024.0)
            return if (mb >= 1024) {
                String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0)
            } else {
                String.format(Locale.getDefault(), "%.1f MB", mb)
            }
        }
    }
}
