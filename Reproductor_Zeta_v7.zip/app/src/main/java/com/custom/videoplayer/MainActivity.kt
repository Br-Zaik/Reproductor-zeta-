package com.custom.videoplayer

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.custom.videoplayer.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val ioExecutor = Executors.newSingleThreadExecutor()

    private var allVideos = mutableListOf<VideoItem>()
    private var displayedVideos = mutableListOf<VideoItem>()
    private var allFolders = mutableListOf<FolderItem>()

    private lateinit var videoAdapter: VideoAdapter
    private lateinit var folderAdapter: FolderAdapter

    private var currentTab = 0
    private var selectedFolderPath: String? = null
    private var sortMode = 0 // 0=Date, 1=Name, 2=Size, 3=Duration
    private var showingPrivateOnly = false
    private var showingFavoritesOnly = false
    private var isGridView = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val videoGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            results[Manifest.permission.READ_MEDIA_VIDEO] == true
        } else {
            results[Manifest.permission.READ_EXTERNAL_STORAGE] == true
        }
        if (videoGranted) {
            loadVideosAsync()
        } else {
            Toast.makeText(this, "Permiso necesario para leer videos", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        isGridView = prefs.getBoolean("is_grid_view", false)
        sortMode = prefs.getInt("sort_mode", 0)

        setupRecyclerView()
        setupTopBarAndTabs()
        setupDrawer()
        setupMiniPlayer()
        setupResumeFab()
        checkAndRequestPermissions()
    }

    override fun onResume() {
        super.onResume()
        updateMiniPlayerUI()
        updateResumeFabVisibility()
        filterAndDisplay(binding.searchView.query?.toString().orEmpty())
    }

    override fun onDestroy() {
        super.onDestroy()
        ioExecutor.shutdownNow()
    }

    private fun setupResumeFab() {
        binding.fabResume.setOnClickListener {
            openLastPlayed()
        }
        updateResumeFabVisibility()
    }

    private fun updateResumeFabVisibility() {
        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        val hasLast = !prefs.getString("last_uri", null).isNullOrEmpty()
        binding.fabResume.visibility = if (hasLast && !PlayerHolder.isAudioBackgroundMode) View.VISIBLE else View.GONE
    }

    private fun setupMiniPlayer() {
        binding.miniPlayerInfo.setOnClickListener {
            val intent = Intent(this, PlayerActivity::class.java).apply {
                putExtra("RESUME_FROM_AUDIO", true)
            }
            startActivity(intent)
        }

        binding.btnMiniPlayPause.setOnClickListener {
            PlayerHolder.player?.let {
                if (it.isPlaying) it.pause() else it.play()
                updateMiniPlayerUI()
            }
        }

        binding.btnMiniNext.setOnClickListener {
            PlayerHolder.player?.let {
                if (it.hasNextMediaItem()) {
                    it.seekToNextMediaItem()
                    PlayerHolder.currentIndex = it.currentMediaItemIndex
                    updateMiniPlayerUI()
                }
            }
        }

        binding.btnMiniClose.setOnClickListener {
            stopService(Intent(this, AudioPlaybackService::class.java).setAction(AudioPlaybackService.ACTION_STOP))
            PlayerHolder.isAudioBackgroundMode = false
            PlayerHolder.player?.pause()
            binding.miniPlayerBar.visibility = View.GONE
            updateResumeFabVisibility()
        }
    }

    private fun updateMiniPlayerUI() {
        val exo = PlayerHolder.player
        if (PlayerHolder.isAudioBackgroundMode && exo != null) {
            binding.miniPlayerBar.visibility = View.VISIBLE
            binding.tvMiniTitle.text = PlayerHolder.videoTitles.getOrNull(PlayerHolder.currentIndex) ?: "Audio en segundo plano"
            binding.btnMiniPlayPause.setImageResource(
                if (exo.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
            )
        } else {
            binding.miniPlayerBar.visibility = View.GONE
        }
    }

    private fun setupRecyclerView() {
        binding.recyclerView.setHasFixedSize(true)
        binding.recyclerView.setItemViewCacheSize(24)

        videoAdapter = VideoAdapter(
            videos = emptyList(),
            onVideoClick = { _, index -> openPlayer(displayedVideos, index) },
            onVideoMenuClick = { video -> showVideoOptionsDialog(video) }
        )
        videoAdapter.setGridMode(isGridView)

        folderAdapter = FolderAdapter(
            folders = emptyList(),
            onFolderClick = { folder ->
                selectedFolderPath = folder.path
                binding.layoutFolderBack.visibility = View.VISIBLE
                binding.tvCurrentFolder.text = "Volver (${folder.name})"
                filterAndDisplay()
            }
        )

        applyLayoutManager(forVideos = true)
        binding.recyclerView.adapter = videoAdapter

        binding.swipeRefresh.setOnRefreshListener {
            loadVideosAsync()
        }

        binding.layoutFolderBack.setOnClickListener {
            selectedFolderPath = null
            binding.layoutFolderBack.visibility = View.GONE
            filterAndDisplay()
        }
    }

    private fun applyLayoutManager(forVideos: Boolean) {
        binding.recyclerView.layoutManager = if (forVideos && isGridView) {
            GridLayoutManager(this, 2)
        } else {
            LinearLayoutManager(this)
        }
        binding.btnToggleView.setImageResource(if (isGridView) R.drawable.ic_list else R.drawable.ic_grid)
    }

    private fun setupTopBarAndTabs() {
        binding.btnMenu.setOnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }

        binding.btnToggleView.setOnClickListener {
            isGridView = !isGridView
            getSharedPreferences("player_prefs", Context.MODE_PRIVATE).edit()
                .putBoolean("is_grid_view", isGridView)
                .apply()
            videoAdapter.setGridMode(isGridView)
            filterAndDisplay(binding.searchView.query?.toString().orEmpty())
        }

        binding.btnMore.setOnClickListener { view ->
            val popup = PopupMenu(this, view)
            popup.menuInflater.inflate(R.menu.main_options_menu, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
                when (item.itemId) {
                    R.id.action_select_all -> {
                        if (displayedVideos.isNotEmpty()) openPlayer(displayedVideos, 0)
                        true
                    }
                    R.id.action_sort_date -> { sortMode = 0; prefs.edit().putInt("sort_mode", 0).apply(); filterAndDisplay(); true }
                    R.id.action_sort_name -> { sortMode = 1; prefs.edit().putInt("sort_mode", 1).apply(); filterAndDisplay(); true }
                    R.id.action_sort_size -> { sortMode = 2; prefs.edit().putInt("sort_mode", 2).apply(); filterAndDisplay(); true }
                    R.id.action_sort_duration -> { sortMode = 3; prefs.edit().putInt("sort_mode", 3).apply(); filterAndDisplay(); true }
                    else -> false
                }
            }
            popup.show()
        }

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                currentTab = tab?.position ?: 0
                showingPrivateOnly = false
                showingFavoritesOnly = false
                binding.tvHeaderTitle.text = "Reproductor Zeta"
                if (currentTab == 0) {
                    selectedFolderPath = null
                    binding.layoutFolderBack.visibility = View.GONE
                }
                filterAndDisplay()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                filterAndDisplay(newText.orEmpty())
                return true
            }
        })
    }

    private fun setupDrawer() {
        binding.navigationView.setNavigationItemSelectedListener { menuItem ->
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            when (menuItem.itemId) {
                R.id.nav_favorites -> {
                    showingPrivateOnly = false
                    showingFavoritesOnly = true
                    selectedFolderPath = null
                    binding.layoutFolderBack.visibility = View.GONE
                    binding.tvHeaderTitle.text = "Favoritos"
                    filterAndDisplay()
                    true
                }
                R.id.nav_last_play -> {
                    openLastPlayed()
                    true
                }
                R.id.nav_network_stream -> {
                    showNetworkStreamDialog()
                    true
                }
                R.id.nav_private_folder -> {
                    handlePrivateFolderAccess()
                    true
                }
                else -> false
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            loadVideosAsync()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun loadVideosAsync() {
        ioExecutor.execute {
            val list = mutableListOf<VideoItem>()
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.DATE_ADDED
            )

            try {
                contentResolver.query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${MediaStore.Video.Media.DATE_ADDED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                    val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                    val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val title = cursor.getString(nameCol) ?: "Video"
                        val duration = cursor.getLong(durCol)
                        val size = cursor.getLong(sizeCol)
                        val path = cursor.getString(dataCol) ?: ""
                        val dateAdded = cursor.getLong(dateCol)

                        val file = File(path)
                        val folderPath = file.parent ?: "/storage/emulated/0"
                        val folderName = file.parentFile?.name ?: "Interno"
                        val contentUri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

                        if (size > 0) {
                            list.add(VideoItem(id, title, duration, size, folderName, folderPath, path, contentUri, dateAdded))
                        }
                    }
                }
            } catch (_: Exception) {
            }

            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    allVideos = list
                    buildFolderList()
                    filterAndDisplay(binding.searchView.query?.toString().orEmpty())
                    binding.swipeRefresh.isRefreshing = false
                }
            }
        }
    }

    private fun buildFolderList() {
        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        val privatePaths = prefs.getStringSet("private_videos", emptySet()) ?: emptySet()
        val publicVideos = allVideos.filter { it.path !in privatePaths }

        allFolders = publicVideos
            .groupBy { it.folderPath }
            .map { (path, items) ->
                FolderItem(
                    name = items.first().folderName,
                    path = path,
                    videoCount = items.size
                )
            }
            .sortedBy { it.name.lowercase() }
            .toMutableList()
    }

    private fun filterAndDisplay(query: String = "") {
        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        val privatePaths = prefs.getStringSet("private_videos", emptySet()) ?: emptySet()
        val favoritePaths = prefs.getStringSet("favorite_videos", emptySet()) ?: emptySet()

        if (showingPrivateOnly) {
            applyLayoutManager(forVideos = true)
            binding.recyclerView.adapter = videoAdapter
            val privList = allVideos.filter { it.path in privatePaths && it.title.contains(query, true) }
            displayedVideos = sortList(privList).toMutableList()
            videoAdapter.updateList(displayedVideos)
            binding.tvEmptyState.visibility = if (displayedVideos.isEmpty()) View.VISIBLE else View.GONE
            return
        }

        if (showingFavoritesOnly) {
            applyLayoutManager(forVideos = true)
            binding.recyclerView.adapter = videoAdapter
            val favList = allVideos.filter { it.path !in privatePaths && it.path in favoritePaths && it.title.contains(query, true) }
            displayedVideos = sortList(favList).toMutableList()
            videoAdapter.updateList(displayedVideos)
            binding.tvEmptyState.visibility = if (displayedVideos.isEmpty()) View.VISIBLE else View.GONE
            return
        }

        val publicVideos = allVideos.filter { it.path !in privatePaths }

        if (currentTab == 0 || selectedFolderPath != null) {
            applyLayoutManager(forVideos = true)
            binding.recyclerView.adapter = videoAdapter
            var filtered = if (selectedFolderPath != null) {
                publicVideos.filter { it.folderPath == selectedFolderPath }
            } else {
                publicVideos
            }
            if (query.isNotBlank()) {
                filtered = filtered.filter { it.title.contains(query, true) }
            }
            displayedVideos = sortList(filtered).toMutableList()
            videoAdapter.updateList(displayedVideos)
            binding.tvEmptyState.visibility = if (displayedVideos.isEmpty()) View.VISIBLE else View.GONE
        } else {
            applyLayoutManager(forVideos = false)
            binding.recyclerView.adapter = folderAdapter
            val filteredFolders = if (query.isNotBlank()) {
                allFolders.filter { it.name.contains(query, true) }
            } else {
                allFolders
            }
            folderAdapter.updateList(filteredFolders)
            binding.tvEmptyState.visibility = if (filteredFolders.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun sortList(list: List<VideoItem>): List<VideoItem> {
        return when (sortMode) {
            1 -> list.sortedBy { it.title.lowercase() }
            2 -> list.sortedByDescending { it.size }
            3 -> list.sortedByDescending { it.duration }
            else -> list.sortedByDescending { it.dateAdded }
        }
    }

    private fun openPlayer(playlist: List<VideoItem>, index: Int) {
        if (playlist.isEmpty()) return
        val uris = ArrayList(playlist.map { it.uri.toString() })
        val titles = ArrayList(playlist.map { it.title })

        val intent = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra("VIDEO_URIS", uris)
            putStringArrayListExtra("VIDEO_TITLES", titles)
            putExtra("START_INDEX", index)
        }
        startActivity(intent)
    }

    private fun openLastPlayed() {
        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        val lastUri = prefs.getString("last_uri", null)
        val lastTitle = prefs.getString("last_title", "Último video")
        val lastPos = prefs.getLong("last_pos", 0L)

        if (lastUri == null) {
            Toast.makeText(this, "Aún no hay videos reproducidos", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra("VIDEO_URIS", arrayListOf(lastUri))
            putStringArrayListExtra("VIDEO_TITLES", arrayListOf(lastTitle))
            putExtra("START_INDEX", 0)
            putExtra("RESUME_POSITION", lastPos)
        }
        startActivity(intent)
    }

    private fun showNetworkStreamDialog() {
        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        val lastStream = prefs.getString("last_stream_url", "") ?: ""

        val input = EditText(this).apply {
            hint = "https://ejemplo.com/video.mp4 o .m3u8"
            setText(lastStream)
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setPadding(48, 32, 48, 32)
        }

        AlertDialog.Builder(this)
            .setTitle("Network Stream")
            .setMessage("Pega el enlace directo del video o transmisión (MP4, HLS/M3U8, DASH, RTSP):")
            .setView(input)
            .setPositiveButton("Reproducir") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) {
                    prefs.edit().putString("last_stream_url", url).apply()
                    val intent = Intent(this, PlayerActivity::class.java).apply {
                        putStringArrayListExtra("VIDEO_URIS", arrayListOf(url))
                        putStringArrayListExtra("VIDEO_TITLES", arrayListOf(Uri.parse(url).lastPathSegment ?: "Stream en red"))
                        putExtra("START_INDEX", 0)
                    }
                    startActivity(intent)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun handlePrivateFolderAccess() {
        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        val savedPin = prefs.getString("private_pin", null)

        val input = EditText(this).apply {
            hint = if (savedPin == null) "Crea un PIN de 4 dígitos" else "Ingresa tu PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setPadding(48, 32, 48, 32)
        }

        AlertDialog.Builder(this)
            .setTitle(if (savedPin == null) "Configurar Carpeta Privada" else "Videos Privados")
            .setView(input)
            .setPositiveButton("Entrar") { _, _ ->
                val entered = input.text.toString().trim()
                if (savedPin == null) {
                    if (entered.length >= 4) {
                        prefs.edit().putString("private_pin", entered).apply()
                        showingPrivateOnly = true
                        showingFavoritesOnly = false
                        binding.tvHeaderTitle.text = "Videos Privados"
                        filterAndDisplay()
                    } else {
                        Toast.makeText(this, "El PIN debe tener al menos 4 dígitos", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    if (entered == savedPin) {
                        showingPrivateOnly = true
                        showingFavoritesOnly = false
                        binding.tvHeaderTitle.text = "Videos Privados"
                        filterAndDisplay()
                    } else {
                        Toast.makeText(this, "PIN incorrecto", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showVideoOptionsDialog(video: VideoItem) {
        val prefs = getSharedPreferences("player_prefs", Context.MODE_PRIVATE)
        val privateSet = prefs.getStringSet("private_videos", emptySet())?.toMutableSet() ?: mutableSetOf()
        val favSet = prefs.getStringSet("favorite_videos", emptySet())?.toMutableSet() ?: mutableSetOf()
        val isPrivate = video.path in privateSet
        val isFav = video.path in favSet

        val options = arrayOf(
            if (isFav) "Quitar de favoritos" else "Agregar a favoritos",
            if (isPrivate) "Quitar de carpeta privada" else "Mover a carpeta privada (PIN)",
            "Compartir video",
            "Reiniciar progreso visto",
            "Detalles del archivo"
        )

        AlertDialog.Builder(this)
            .setTitle(video.title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        if (isFav) favSet.remove(video.path) else favSet.add(video.path)
                        prefs.edit().putStringSet("favorite_videos", favSet).apply()
                        filterAndDisplay(binding.searchView.query?.toString().orEmpty())
                        Toast.makeText(this, if (isFav) "Quitado de favoritos" else "Agregado a favoritos", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        if (isPrivate) privateSet.remove(video.path) else privateSet.add(video.path)
                        prefs.edit().putStringSet("private_videos", privateSet).apply()
                        buildFolderList()
                        filterAndDisplay()
                        Toast.makeText(this, if (isPrivate) "Video restaurado" else "Movido a carpeta privada", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "video/*"
                            putExtra(Intent.EXTRA_STREAM, video.uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(shareIntent, "Compartir video"))
                    }
                    3 -> {
                        getSharedPreferences("video_progress_prefs", Context.MODE_PRIVATE).edit()
                            .remove(video.uri.toString())
                            .apply()
                        videoAdapter.notifyDataSetChanged()
                        Toast.makeText(this, "Progreso reiniciado", Toast.LENGTH_SHORT).show()
                    }
                    4 -> {
                        val infoText = "Archivo: ${video.title}\nDuración: ${VideoAdapter.formatDuration(video.duration)}\nTamaño: ${VideoAdapter.formatSize(video.size)}\nRuta: ${video.path}"
                        AlertDialog.Builder(this)
                            .setTitle("Información")
                            .setMessage(infoText)
                            .setPositiveButton("Cerrar", null)
                            .show()
                    }
                }
            }
            .show()
    }
}
